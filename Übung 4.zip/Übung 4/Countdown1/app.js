require("./countdown");
const setCountdown = require("./countdown");
setCountdown(5);